package com.run;

import com.view.MemberView;

public class MemberRun {

	public static void main(String[] args) {
		new MemberView().menu();
		
		/*
		 *  -JDBC02_Product 프로젝트에서 구현한 내용을 참고하여 구현.
		 *  -service,dao 클래스는 작성된 interface를 상속받아 구현.
		 *  -쿼리문은 Memberdao인터페이스 내에 작성된 내용을 사용하여 구현.
		 *  -메뉴는 JDBC02프로젝트 참고하여 구현.
		 */
	}

}
