package com.view;

public class MemberView {
	public void menu() {
		
	}
}
