package com.model.dto;

public class Member {

}
